package com.example.utstry4

import androidx.fragment.app.Fragment

class TermsFragment : Fragment(R.layout.fragment_terms) {
}