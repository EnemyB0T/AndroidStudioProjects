package com.example.utstry4

import androidx.fragment.app.Fragment

class SettingsFragment : Fragment(R.layout.fragment_settings) {
}