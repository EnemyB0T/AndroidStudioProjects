package com.example.utstry4

import androidx.fragment.app.Fragment

class SearchFragment : Fragment(R.layout.fragment_search) {
}